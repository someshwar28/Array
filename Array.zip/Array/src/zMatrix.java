import java.util.Scanner;

public class zMatrix {
	/*
	 * 9.User will enter the element in M*M order matrix that is square matrix
	 * now you have to print first row, last row, first column, and last column
	 * elements. Code should be applicable for matrix of any order.
	 */

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the size of the array  ");
		
		int size = sc.nextInt();
	
		int square[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		
		System.out.println("Enter elements of the array (Strings)  ");

		for (int i = 1; i <= size; i++) {
			square[i][i] = sc.nextInt();
		}
		
		for (int i = 1; i <= size; i++) {
			for (int j = 0; j < 5; j++) {
				
				if (i==1 && j ==1) {
					System.out.print("  ");
					continue;
				}
				System.out.print(square[i][j] + " ");
			}
			System.out.println();

		}

	}

}
